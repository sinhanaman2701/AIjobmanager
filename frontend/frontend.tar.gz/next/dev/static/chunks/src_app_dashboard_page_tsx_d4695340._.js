(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_16c9efd5._.js",
  "static/chunks/src_ee12b28d._.js"
],
    source: "dynamic"
});
