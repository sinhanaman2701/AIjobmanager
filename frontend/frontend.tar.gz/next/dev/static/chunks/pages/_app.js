__turbopack_load_page_chunks__("/_app", [
  "static/chunks/node_modules_next_dist_compiled_9c6fb6f2._.js",
  "static/chunks/node_modules_next_dist_shared_lib_49f863e2._.js",
  "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
  "static/chunks/node_modules_next_dist_51d2d3b1._.js",
  "static/chunks/node_modules_next_app_72f3d36f.js",
  "static/chunks/[next]_entry_page-loader_ts_742e4b53._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_7f09fef0._.js",
  "static/chunks/[root-of-the-server]__45f039c3._.js",
  "static/chunks/pages__app_2da965e7._.js",
  "static/chunks/turbopack-pages__app_1a790c4c._.js"
])
