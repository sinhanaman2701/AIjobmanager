(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_c1c92e38._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_motion-dom_dist_es_a71b15d2._.js",
  "static/chunks/node_modules_framer-motion_dist_es_3ced7412._.js",
  "static/chunks/node_modules_three_build_three_core_996ef05a.js",
  "static/chunks/node_modules_three_build_three_module_0c59ee63.js",
  "static/chunks/node_modules_c639f6e3._.js",
  "static/chunks/src_components_ui_shiny-button_ca76585b.css"
],
    source: "dynamic"
});
